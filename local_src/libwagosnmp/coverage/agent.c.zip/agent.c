<tr class="noCover">
<td class="line"><a name='1'>1</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='2'>2</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;Copyright&nbsp;(c)&nbsp;WAGO&nbsp;GmbH&nbsp;&amp;&nbsp;Co.&nbsp;KG</td>
</tr>
<tr class="noCover">
<td class="line"><a name='3'>3</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='4'>4</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;PROPRIETARY&nbsp;RIGHTS&nbsp;are&nbsp;involved&nbsp;in&nbsp;the&nbsp;subject&nbsp;matter&nbsp;of&nbsp;this&nbsp;material.</td>
</tr>
<tr class="noCover">
<td class="line"><a name='5'>5</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;All&nbsp;manufacturing,&nbsp;reproduction,&nbsp;use&nbsp;and&nbsp;sales&nbsp;rights&nbsp;pertaining&nbsp;to&nbsp;this</td>
</tr>
<tr class="noCover">
<td class="line"><a name='6'>6</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;subject&nbsp;matter&nbsp;are&nbsp;governed&nbsp;by&nbsp;the&nbsp;license&nbsp;agreement.&nbsp;The&nbsp;recipient&nbsp;of&nbsp;this</td>
</tr>
<tr class="noCover">
<td class="line"><a name='7'>7</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;software&nbsp;implicitly&nbsp;accepts&nbsp;the&nbsp;terms&nbsp;of&nbsp;the&nbsp;license.</td>
</tr>
<tr class="noCover">
<td class="line"><a name='8'>8</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='9'>9</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='10'>10</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='11'>11</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;\file&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;server.c</td>
</tr>
<tr class="noCover">
<td class="line"><a name='12'>12</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='13'>13</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;\version&nbsp;&nbsp;$Rev:&nbsp;66938&nbsp;$</td>
</tr>
<tr class="noCover">
<td class="line"><a name='14'>14</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='15'>15</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;\brief&nbsp;&nbsp;&nbsp;&nbsp;&lt;Insert&nbsp;description&nbsp;here&gt;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='16'>16</a></td>
<td class="hits"></td>
<td class="code">///</td>
</tr>
<tr class="noCover">
<td class="line"><a name='17'>17</a></td>
<td class="hits"></td>
<td class="code">///&nbsp;&nbsp;\author&nbsp;&nbsp;&nbsp;&lt;author&gt;&nbsp;:&nbsp;WAGO&nbsp;GmbH&nbsp;&amp;&nbsp;Co.&nbsp;KG</td>
</tr>
<tr class="noCover">
<td class="line"><a name='18'>18</a></td>
<td class="hits"></td>
<td class="code">//------------------------------------------------------------------------------</td>
</tr>
<tr class="noCover">
<td class="line"><a name='19'>19</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='20'>20</a></td>
<td class="hits"></td>
<td class="code">#include&nbsp;&lt;unistd.h&gt;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='21'>21</a></td>
<td class="hits"></td>
<td class="code">#include&nbsp;"wagosnmp_API.h"</td>
</tr>
<tr class="noCover">
<td class="line"><a name='22'>22</a></td>
<td class="hits"></td>
<td class="code">#include&nbsp;"wagosnmp_internal.h"</td>
</tr>
<tr class="noCover">
<td class="line"><a name='23'>23</a></td>
<td class="hits"></td>
<td class="code">#include&nbsp;&lt;net-snmp/net-snmp-config.h&gt;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='24'>24</a></td>
<td class="hits"></td>
<td class="code">#include&nbsp;&lt;net-snmp/net-snmp-includes.h&gt;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='25'>25</a></td>
<td class="hits"></td>
<td class="code">#include&nbsp;&lt;net-snmp/agent/net-snmp-agent-includes.h&gt;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='26'>26</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='27'>27</a></td>
<td class="hits"></td>
<td class="code">typedef&nbsp;struct&nbsp;stHandlerList&nbsp;tHandlerList;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='28'>28</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='29'>29</a></td>
<td class="hits"></td>
<td class="code">struct&nbsp;stHandlerList&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='30'>30</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;netsnmp_handler_registration&nbsp;*&nbsp;handler;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='31'>31</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;tHandlerList&nbsp;*&nbsp;pNext;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='32'>32</a></td>
<td class="hits"></td>
<td class="code">};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='33'>33</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='34'>34</a></td>
<td class="hits"></td>
<td class="code">static&nbsp;tHandlerList&nbsp;*&nbsp;pHandlerListRoot&nbsp;=&nbsp;NULL;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='35'>35</a></td>
<td class="hits"></td>
<td class="code">static&nbsp;pthread_t&nbsp;stThreadID&nbsp;=&nbsp;0;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='36'>36</a></td>
<td class="hits"></td>
<td class="code">static&nbsp;mqd_t&nbsp;trap_queue&nbsp;=&nbsp;-1;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='37'>37</a></td>
<td class="hits"></td>
<td class="code">static&nbsp;sem_t*&nbsp;oidMutex&nbsp;=&nbsp;NULL;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='38'>38</a></td>
<td class="hits"></td>
<td class="code">static&nbsp;int&nbsp;&nbsp;&nbsp;&nbsp;oidShmFd&nbsp;=&nbsp;-1;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='39'>39</a></td>
<td class="hits"></td>
<td class="code">static&nbsp;tOidShm&nbsp;*&nbsp;pOidShm&nbsp;=&nbsp;NULL;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='40'>40</a></td>
<td class="hits"></td>
<td class="code">static&nbsp;int&nbsp;&nbsp;&nbsp;localShmSize&nbsp;=&nbsp;sizeof(tOidShm);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='41'>41</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='42'>42</a></td>
<td class="hits"></td>
<td class="code">int&nbsp;__attribute__((weak))&nbsp;netsnmp_unregister_handler(netsnmp_handler_registration&nbsp;*reginfo)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='43'>43</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='44'>44</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;(void)&nbsp;reginfo;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='45'>45</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;1;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='46'>46</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='47'>47</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='48'>48</a></td>
<td class="hits"></td>
<td class="code">netsnmp_handler_registration&nbsp;*&nbsp;__attribute__((weak))&nbsp;netsnmp_create_handler_registration(const&nbsp;char&nbsp;*name,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='49'>49</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Netsnmp_Node_Handler*&nbsp;handler_access_method,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='50'>50</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;const&nbsp;oid&nbsp;*reg_oid,&nbsp;size_t&nbsp;reg_oid_len,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='51'>51</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;modes)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='52'>52</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='53'>53</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;(void)name;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='54'>54</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;(void)handler_access_method;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='55'>55</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;(void)reg_oid;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='56'>56</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;(void)reg_oid_len;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='57'>57</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;(void)modes;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='58'>58</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;NULL;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='59'>59</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='60'>60</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='61'>61</a></td>
<td class="hits"></td>
<td class="code">int&nbsp;__attribute__((weak))&nbsp;netsnmp_register_instance(netsnmp_handler_registration&nbsp;*&nbsp;reginfo)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='62'>62</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='63'>63</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;(void)&nbsp;reginfo;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='64'>64</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;1;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='65'>65</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='66'>66</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='67'>67</a></td>
<td class="hits"></td>
<td class="code">int&nbsp;__attribute__((weak))&nbsp;netsnmp_set_request_error(netsnmp_agent_request_info&nbsp;&nbsp;*reqinfo,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='68'>68</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;netsnmp_request_info&nbsp;*request,&nbsp;int&nbsp;error_value)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='69'>69</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='70'>70</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;(void)reqinfo;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='71'>71</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;(void)request;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='72'>72</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;(void)error_value;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='73'>73</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;1;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='74'>74</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='75'>75</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='76'>76</a></td>
<td class="hits"></td>
<td class="code">int&nbsp;__attribute__((weak))&nbsp;netsnmp_send_traps(int&nbsp;trap,&nbsp;int&nbsp;specific,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='77'>77</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;const&nbsp;oid&nbsp;*&nbsp;enterprise,&nbsp;int&nbsp;enterprise_length,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='78'>78</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;netsnmp_variable_list&nbsp;*&nbsp;vars,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='79'>79</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;const&nbsp;char&nbsp;*&nbsp;context,&nbsp;int&nbsp;flags)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='80'>80</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='81'>81</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;(void)trap;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='82'>82</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;(void)specific;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='83'>83</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;(void)enterprise;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='84'>84</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;(void)enterprise_length;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='85'>85</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;(void)vars;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='86'>86</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;(void)context;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='87'>87</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;(void)flags;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='88'>88</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;1;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='89'>89</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='90'>90</a></td>
<td class="hits"></td>
<td class="code">void&nbsp;__attribute__((weak))&nbsp;send_easy_trap(int&nbsp;a,&nbsp;int&nbsp;b)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='91'>91</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='92'>92</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;(void)a;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='93'>93</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;(void)b;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='94'>94</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='95'>95</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='96'>96</a></td>
<td class="hits">0</td>
<td class="code">static&nbsp;void&nbsp;_TrapSend(tWagoSnmpMsg&nbsp;*&nbsp;trap)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='97'>97</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='98'>98</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;netsnmp_variable_list&nbsp;*notification_vars&nbsp;=&nbsp;NULL;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='99'>99</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='100'>100</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='101'>101</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if(trap-&gt;variable.type&nbsp;!=&nbsp;ASN_NULL)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='102'>102</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='103'>103</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;snmp_varlist_add_variable(&amp;notification_vars,</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='104'>104</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;trap-&gt;variable.sOID,&nbsp;&nbsp;trap-&gt;variable.sOID_length,</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='105'>105</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;trap-&gt;variable.type,</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='106'>106</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(u_char&nbsp;*)&nbsp;trap-&gt;variable.buf,trap-&gt;variable.len);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='107'>107</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='108'>108</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;netsnmp_send_traps&nbsp;&nbsp;(trap-&gt;trap_type,trap-&gt;specific_type,trap-&gt;enterprise,trap-&gt;enterprise_length,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='109'>109</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;notification_vars,&nbsp;NULL,0);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='110'>110</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;snmp_free_varbind(notification_vars);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='111'>111</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='112'>112</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='113'>113</a></td>
<td class="hits">0</td>
<td class="code">static&nbsp;int&nbsp;_OidHandler(netsnmp_mib_handler&nbsp;*handler,&nbsp;netsnmp_handler_registration&nbsp;*reginfo,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='114'>114</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;netsnmp_agent_request_info&nbsp;*reqinfo,&nbsp;netsnmp_request_info&nbsp;*requests)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='115'>115</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='116'>116</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;(void)(handler);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='117'>117</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;(void)(reginfo);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='118'>118</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;int&nbsp;ret=SNMP_ERR_NOERROR;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='119'>119</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;tOidObject&nbsp;*&nbsp;object&nbsp;=&nbsp;NULL;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='120'>120</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='121'>121</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;/*build_oid_string(szOID,&nbsp;requests-&gt;requestvb-&gt;name,&nbsp;requests-&gt;requestvb-&gt;name_length);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='122'>122</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;pagent_oid&nbsp;=&nbsp;find_agent_oid(szOID);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='123'>123</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;*/</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='124'>124</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;AGENT_MutexLock();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='125'>125</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;object&nbsp;=&nbsp;AGENT_GetOidObject(requests-&gt;requestvb-&gt;name,requests-&gt;requestvb-&gt;name_length);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='126'>126</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if(object&nbsp;!=&nbsp;NULL)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='127'>127</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='128'>128</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;switch&nbsp;(reqinfo-&gt;mode)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='129'>129</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='130'>130</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MODE_GET:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='131'>131</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MODE_GETNEXT:</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='132'>132</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;snmp_set_var_typed_value(requests-&gt;requestvb,&nbsp;object-&gt;type,&nbsp;object-&gt;buf,&nbsp;object-&gt;len);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='133'>133</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='134'>134</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='135'>135</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MODE_SET_RESERVE1:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='136'>136</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;check&nbsp;type</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='137'>137</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if(object-&gt;type&nbsp;!=&nbsp;requests-&gt;requestvb-&gt;type)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='138'>138</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='139'>139</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;netsnmp_set_request_error(reqinfo,&nbsp;requests,&nbsp;SNMP_ERR_WRONGTYPE);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='140'>140</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ret&nbsp;=&nbsp;SNMP_ERR_WRONGTYPE;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='141'>141</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='142'>142</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='143'>143</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='144'>144</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MODE_SET_RESERVE2:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='145'>145</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;no&nbsp;storage&nbsp;for&nbsp;old&nbsp;value&nbsp;-&gt;&nbsp;no&nbsp;action</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='146'>146</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='147'>147</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MODE_SET_ACTION:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='148'>148</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;update&nbsp;current&nbsp;value</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='149'>149</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if(object-&gt;readOnly&nbsp;==&nbsp;0)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='150'>150</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='151'>151</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;AGENT_SetOidObjectValue(object,requests-&gt;requestvb);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='152'>152</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='153'>153</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;else</td>
</tr>
<tr class="noCover">
<td class="line"><a name='154'>154</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='155'>155</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;netsnmp_set_request_error(reqinfo,&nbsp;requests,&nbsp;SNMP_ERR_NOTWRITABLE);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='156'>156</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='157'>157</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='158'>158</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MODE_SET_UNDO:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='159'>159</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;restore&nbsp;information&nbsp;-&gt;&nbsp;no&nbsp;action</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='160'>160</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='161'>161</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MODE_SET_COMMIT:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='162'>162</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;commit&nbsp;set&nbsp;value&nbsp;-&gt;&nbsp;no&nbsp;action</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='163'>163</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='164'>164</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MODE_SET_FREE:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='165'>165</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;free&nbsp;set&nbsp;value&nbsp;-&gt;&nbsp;no&nbsp;action</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='166'>166</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='167'>167</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='168'>168</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='169'>169</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;else</td>
</tr>
<tr class="noCover">
<td class="line"><a name='170'>170</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='171'>171</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;error</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='172'>172</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;netsnmp_set_request_error(reqinfo,&nbsp;requests,&nbsp;SNMP_ERR_RESOURCEUNAVAILABLE);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='173'>173</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='174'>174</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;AGENT_MutexUnlock();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='175'>175</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;ret;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='176'>176</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='177'>177</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='178'>178</a></td>
<td class="hits">0</td>
<td class="code">static&nbsp;void&nbsp;_AddHandlerToList(netsnmp_handler_registration&nbsp;*new_handler)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='179'>179</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='180'>180</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='181'>181</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;tHandlerList&nbsp;*&nbsp;pNew&nbsp;=&nbsp;malloc(sizeof(tHandlerList));</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='182'>182</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;pNew-&gt;handler&nbsp;=&nbsp;new_handler;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='183'>183</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;pNew-&gt;pNext&nbsp;=&nbsp;NULL;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='184'>184</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if(pHandlerListRoot&nbsp;==&nbsp;NULL)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='185'>185</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='186'>186</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;pHandlerListRoot&nbsp;=&nbsp;pNew;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='187'>187</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='188'>188</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;else</td>
</tr>
<tr class="noCover">
<td class="line"><a name='189'>189</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='190'>190</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;tHandlerList&nbsp;*&nbsp;pAct&nbsp;=&nbsp;pHandlerListRoot;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='191'>191</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;while(pAct-&gt;pNext&nbsp;!=&nbsp;NULL)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='192'>192</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='193'>193</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;pAct&nbsp;=&nbsp;pAct-&gt;pNext;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='194'>194</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='195'>195</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;pAct-&gt;pNext&nbsp;=&nbsp;pNew;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='196'>196</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='197'>197</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='198'>198</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='199'>199</a></td>
<td class="hits">0</td>
<td class="code">static&nbsp;void&nbsp;_RegisterOIDHandler(oid&nbsp;*&nbsp;anOID,&nbsp;size_t&nbsp;anOID_length)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='200'>200</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='201'>201</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;netsnmp_handler_registration&nbsp;*new_handler&nbsp;=&nbsp;NULL;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='202'>202</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;new_handler&nbsp;=&nbsp;netsnmp_create_handler_registration(WAGOSNMP_AGENT_NAME,_OidHandler,&nbsp;\</td>
</tr>
<tr class="noCover">
<td class="line"><a name='203'>203</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;anOID,anOID_length,HANDLER_CAN_RWRITE);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='204'>204</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if(new_handler)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='205'>205</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='206'>206</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='207'>207</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;register&nbsp;handler</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='208'>208</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;/*iTmpRet&nbsp;=*/&nbsp;netsnmp_register_instance(new_handler);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='209'>209</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;_AddHandlerToList(new_handler);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='210'>210</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='211'>211</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='212'>212</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='213'>213</a></td>
<td class="hits">0</td>
<td class="code">static&nbsp;void&nbsp;_RegisterOID(tWagoSnmpMsg&nbsp;*&nbsp;msg)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='214'>214</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='215'>215</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='216'>216</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;AGENT_CreateShm();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='217'>217</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;AGENT_RemapShm();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='218'>218</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;AGENT_MutexLock();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='219'>219</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if(oidShmFd&nbsp;&gt;=&nbsp;0)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='220'>220</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='221'>221</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;tOidObject&nbsp;*&nbsp;pAct&nbsp;=&nbsp;AGENT_GetOidObject(msg-&gt;variable.sOID,&nbsp;msg-&gt;variable.sOID_length);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='222'>222</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if(pAct&nbsp;!=&nbsp;NULL)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='223'>223</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='224'>224</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_RegisterOIDHandler(pAct-&gt;anOID,pAct-&gt;anOID_length);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='225'>225</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='226'>226</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='227'>227</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='228'>228</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;AGENT_MutexUnlock();</td>
</tr>
<tr class="noCover">
<td class="line"><a name='229'>229</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='230'>230</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='231'>231</a></td>
<td class="hits">0</td>
<td class="code">static&nbsp;void&nbsp;_Reset(void)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='232'>232</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='233'>233</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;tHandlerList&nbsp;*&nbsp;pAct&nbsp;=&nbsp;pHandlerListRoot;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='234'>234</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='235'>235</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;while(pAct&nbsp;!=&nbsp;NULL)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='236'>236</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='237'>237</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;tHandlerList&nbsp;*&nbsp;del&nbsp;=&nbsp;pAct;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='238'>238</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;netsnmp_unregister_handler(del-&gt;handler);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='239'>239</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;pAct&nbsp;=&nbsp;pAct-&gt;pNext;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='240'>240</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;free(del);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='241'>241</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='242'>242</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;pHandlerListRoot&nbsp;=&nbsp;NULL;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='243'>243</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;AGENT_CloseMutex();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='244'>244</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;AGENT_CloseShm();</td>
</tr>
<tr class="noCover">
<td class="line"><a name='245'>245</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='246'>246</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='247'>247</a></td>
<td class="hits">0</td>
<td class="code">static&nbsp;void*&nbsp;_ServerMain()</td>
</tr>
<tr class="noCover">
<td class="line"><a name='248'>248</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='249'>249</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;while(1)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='250'>250</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='251'>251</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;struct&nbsp;pollfd&nbsp;fdrec;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='252'>252</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;fdrec.fd&nbsp;=&nbsp;trap_queue;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='253'>253</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;fdrec.events&nbsp;=&nbsp;POLLIN;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='254'>254</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;fdrec.revents&nbsp;=&nbsp;0;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='255'>255</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;wait&nbsp;for&nbsp;message&nbsp;(forever)&nbsp;used&nbsp;because&nbsp;we&nbsp;opened&nbsp;fd&nbsp;in&nbsp;O_NONBLOCK&nbsp;mode</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='256'>256</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if(0&nbsp;&lt;&nbsp;poll(&amp;fdrec,&nbsp;1,&nbsp;-1))</td>
</tr>
<tr class="noCover">
<td class="line"><a name='257'>257</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='258'>258</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;tWagoSnmpMsg&nbsp;stMessage;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='259'>259</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if(0&nbsp;&lt;&nbsp;mq_receive(trap_queue,&nbsp;(char&nbsp;*)&nbsp;&amp;stMessage,</td>
</tr>
<tr class="noCover">
<td class="line"><a name='260'>260</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;sizeof(tWagoSnmpMsg),NULL))</td>
</tr>
<tr class="noCover">
<td class="line"><a name='261'>261</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='262'>262</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;switch(stMessage.type)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='263'>263</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='264'>264</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MSG_TYPE_TRAP_EASY:</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='265'>265</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;send_easy_trap(6,stMessage.specific_type);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='266'>266</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='267'>267</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MSG_TYPE_TRAP:</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='268'>268</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_TrapSend(&amp;stMessage);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='269'>269</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='270'>270</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MSG_TYPE_REGISTER_OID:</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='271'>271</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_RegisterOID(&amp;stMessage);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='272'>272</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='273'>273</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MSG_TYPE_RESET:</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='274'>274</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_Reset();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='275'>275</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='276'>276</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;MSG_TYPE_NONE:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='277'>277</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;default:</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='278'>278</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='279'>279</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='280'>280</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='281'>281</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='282'>282</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='283'>283</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='284'>284</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;return&nbsp;0;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='285'>285</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='286'>286</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='287'>287</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='288'>288</a></td>
<td class="hits">0</td>
<td class="code">static&nbsp;mqd_t&nbsp;_OpenServerQueue(const&nbsp;char&nbsp;*&nbsp;name,&nbsp;long&nbsp;int&nbsp;msgsz,&nbsp;long&nbsp;int&nbsp;maxmsg)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='289'>289</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='290'>290</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;mqd_t&nbsp;ret&nbsp;=&nbsp;-1;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='291'>291</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;struct&nbsp;mq_attr&nbsp;mqAttr;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='292'>292</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='293'>293</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;mqAttr.mq_flags&nbsp;=&nbsp;0;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='294'>294</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;mqAttr.mq_maxmsg&nbsp;=&nbsp;maxmsg;//create&nbsp;a&nbsp;good&nbsp;size&nbsp;for&nbsp;the&nbsp;message&nbsp;buffer</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='295'>295</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;mqAttr.mq_msgsize&nbsp;=&nbsp;msgsz;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='296'>296</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;ret&nbsp;=&nbsp;mq_open(name,&nbsp;OPEN_SERVER_MODE,&nbsp;CREAT_MODE,&nbsp;&amp;mqAttr&nbsp;);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='297'>297</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if(ret&nbsp;&lt;&nbsp;0)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='298'>298</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='299'>299</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;mq_unlink(name);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='300'>300</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;ret&nbsp;=&nbsp;mq_open(name,&nbsp;OPEN_SERVER_MODE,&nbsp;CREAT_MODE,&nbsp;&amp;mqAttr&nbsp;);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='301'>301</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='302'>302</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='303'>303</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;ret;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='304'>304</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='305'>305</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='306'>306</a></td>
<td class="hits">0</td>
<td class="code">static&nbsp;void&nbsp;_InitExistingShm(void)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='307'>307</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='308'>308</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;AGENT_MutexLock();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='309'>309</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;AGENT_CreateShm();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='310'>310</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if(oidShmFd&nbsp;&gt;=&nbsp;0)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='311'>311</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='312'>312</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;tOidObject&nbsp;*&nbsp;pAct&nbsp;=&nbsp;AGENT_GetNextOidObject(NULL);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='313'>313</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;while(pAct&nbsp;!=&nbsp;NULL)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='314'>314</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='315'>315</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_RegisterOIDHandler(pAct-&gt;anOID,&nbsp;pAct-&gt;anOID_length);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='316'>316</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;pAct&nbsp;=&nbsp;AGENT_GetNextOidObject(pAct);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='317'>317</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='318'>318</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='319'>319</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;AGENT_MutexUnlock();</td>
</tr>
<tr class="noCover">
<td class="line"><a name='320'>320</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='321'>321</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='322'>322</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;void&nbsp;AGENT_InitServerCommunication(unsigned&nbsp;int&nbsp;clientreg,&nbsp;void&nbsp;*clientarg)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='323'>323</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='324'>324</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;(void)&nbsp;clientreg;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='325'>325</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;(void)&nbsp;clientarg;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='326'>326</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;snmp_log&nbsp;&nbsp;(LOG_INFO,"Init&nbsp;WAGO&nbsp;snmp&nbsp;plugin\n");</td>
</tr>
<tr class="noCover">
<td class="line"><a name='327'>327</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='328'>328</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;_InitExistingShm();</td>
</tr>
<tr class="noCover">
<td class="line"><a name='329'>329</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='330'>330</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;trap_queue&nbsp;=&nbsp;_OpenServerQueue(TRAP_AGENT_MQ,sizeof(tWagoSnmpMsg),&nbsp;1);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='331'>331</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='332'>332</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if((pthread_create(&amp;stThreadID,&nbsp;NULL,&nbsp;_ServerMain,&nbsp;NULL))&nbsp;==&nbsp;-1)</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='333'>333</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;DEBUGMSGTL(("plcsnmp_trap_agent",&nbsp;"error&nbsp;while&nbsp;starting&nbsp;thread\n"));</td>
</tr>
<tr class="noCover">
<td class="line"><a name='334'>334</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;else</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='335'>335</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;DEBUGMSGTL(("plcsnmp_trap_agent",&nbsp;"starting&nbsp;thread&nbsp;ok\n"));</td>
</tr>
<tr class="noCover">
<td class="line"><a name='336'>336</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='337'>337</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='338'>338</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;int&nbsp;AGENT_CreateMutex()</td>
</tr>
<tr class="noCover">
<td class="line"><a name='339'>339</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='340'>340</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;int&nbsp;ret&nbsp;=&nbsp;0;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='341'>341</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if(oidMutex&nbsp;==&nbsp;NULL)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='342'>342</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='343'>343</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;oidMutex&nbsp;=&nbsp;sem_open(WAGO_SNMP_OID_MUTEX,O_RDWR|O_CREAT|O_EXCL,&nbsp;0666,1);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='344'>344</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if(oidMutex&nbsp;==&nbsp;SEM_FAILED)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='345'>345</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='346'>346</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if(errno&nbsp;==&nbsp;EEXIST)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='347'>347</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='348'>348</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;oidMutex&nbsp;=&nbsp;sem_open(WAGO_SNMP_OID_MUTEX,O_RDWR);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='349'>349</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='350'>350</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if(oidMutex&nbsp;==&nbsp;SEM_FAILED)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='351'>351</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='352'>352</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ret&nbsp;=&nbsp;-1;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='353'>353</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;oidMutex&nbsp;=&nbsp;NULL;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='354'>354</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='355'>355</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='356'>356</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='357'>357</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;ret;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='358'>358</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='359'>359</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='360'>360</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;void&nbsp;AGENT_MutexLock()</td>
</tr>
<tr class="noCover">
<td class="line"><a name='361'>361</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='362'>362</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if(AGENT_CreateMutex()&nbsp;&gt;=&nbsp;0)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='363'>363</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='364'>364</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;sem_wait(oidMutex);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='365'>365</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='366'>366</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='367'>367</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;void&nbsp;AGENT_MutexUnlock()</td>
</tr>
<tr class="noCover">
<td class="line"><a name='368'>368</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='369'>369</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if(AGENT_CreateMutex()&nbsp;&gt;=&nbsp;0)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='370'>370</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='371'>371</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;sem_post(oidMutex);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='372'>372</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='373'>373</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='374'>374</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='375'>375</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;void&nbsp;AGENT_CloseMutex()</td>
</tr>
<tr class="noCover">
<td class="line"><a name='376'>376</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='377'>377</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if(oidMutex&nbsp;!=&nbsp;NULL)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='378'>378</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='379'>379</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;sem_close(oidMutex);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='380'>380</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;oidMutex=NULL;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='381'>381</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='382'>382</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='383'>383</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='384'>384</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;void&nbsp;AGENT_DestroyMutex()</td>
</tr>
<tr class="noCover">
<td class="line"><a name='385'>385</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='386'>386</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if(AGENT_CreateMutex()&nbsp;&gt;=&nbsp;0)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='387'>387</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='388'>388</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;AGENT_CloseMutex();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='389'>389</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;sem_unlink(WAGO_SNMP_OID_MUTEX);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='390'>390</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='391'>391</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='392'>392</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='393'>393</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;void&nbsp;AGENT_RemapShm()</td>
</tr>
<tr class="noCover">
<td class="line"><a name='394'>394</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='395'>395</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;int&nbsp;newSize;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='396'>396</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;//Compile&nbsp;Errors</td>
</tr>
<tr class="noCover">
<td class="line"><a name='397'>397</a></td>
<td class="hits"></td>
<td class="code">&nbsp;//&nbsp;pOidShm&nbsp;=&nbsp;mremap(pOidShm,localShmSize,pOidShm-&gt;oidShmSize,&nbsp;MREMAP_MAYMOVE);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='398'>398</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;newSize&nbsp;=&nbsp;pOidShm-&gt;oidShmSize;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='399'>399</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;munmap(pOidShm,localShmSize);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='400'>400</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;pOidShm&nbsp;=&nbsp;mmap(0,newSize,PROT_READ|PROT_WRITE,MAP_SHARED,oidShmFd,0);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='401'>401</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;localShmSize&nbsp;=&nbsp;newSize;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='402'>402</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='403'>403</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='404'>404</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;void&nbsp;AGENT_CreateShm()</td>
</tr>
<tr class="noCover">
<td class="line"><a name='405'>405</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='406'>406</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if(oidShmFd&nbsp;&lt;&nbsp;0)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='407'>407</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='408'>408</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;oidShmFd&nbsp;=&nbsp;shm_open(WAGO_SNMP_OID_SHM,O_RDWR|O_CREAT|O_EXCL,&nbsp;0666);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='409'>409</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if(oidShmFd&nbsp;&lt;&nbsp;0)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='410'>410</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='411'>411</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(errno&nbsp;==&nbsp;EEXIST)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='412'>412</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='413'>413</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;oidShmFd&nbsp;=&nbsp;shm_open(WAGO_SNMP_OID_SHM,O_RDWR,0666);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='414'>414</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;pOidShm&nbsp;=&nbsp;mmap(0,sizeof(tOidShm),PROT_READ|PROT_WRITE,MAP_SHARED,oidShmFd,0);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='415'>415</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;AGENT_RemapShm();</td>
</tr>
<tr class="noCover">
<td class="line"><a name='416'>416</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='417'>417</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='418'>418</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;else</td>
</tr>
<tr class="noCover">
<td class="line"><a name='419'>419</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='420'>420</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ftruncate(oidShmFd,sizeof(tOidShm));</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='421'>421</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;pOidShm&nbsp;=&nbsp;mmap(0,sizeof(tOidShm),PROT_READ|PROT_WRITE,MAP_SHARED,oidShmFd,0);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='422'>422</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;pOidShm-&gt;oidShmSize&nbsp;=&nbsp;sizeof(tOidShm);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='423'>423</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;localShmSize&nbsp;=&nbsp;pOidShm-&gt;oidShmSize;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='424'>424</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;pOidShm-&gt;oidCount&nbsp;=&nbsp;0;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='425'>425</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='426'>426</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='427'>427</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='428'>428</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='429'>429</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;void&nbsp;AGENT_CloseShm(void)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='430'>430</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='431'>431</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if(oidShmFd&nbsp;&gt;=&nbsp;0)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='432'>432</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='433'>433</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;munmap(pOidShm,pOidShm-&gt;oidShmSize);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='434'>434</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;pOidShm&nbsp;=&nbsp;NULL;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='435'>435</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;close(oidShmFd);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='436'>436</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;oidShmFd&nbsp;=&nbsp;-1;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='437'>437</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;localShmSize&nbsp;=&nbsp;sizeof(tOidShm);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='438'>438</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='439'>439</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='440'>440</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='441'>441</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;void&nbsp;AGENT_DestroyShm(void)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='442'>442</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='443'>443</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;AGENT_CloseShm();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='444'>444</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;shm_unlink(WAGO_SNMP_OID_SHM);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='445'>445</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='446'>446</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='447'>447</a></td>
<td class="hits"></td>
<td class="code">/*&nbsp;adding&nbsp;size&nbsp;bytes&nbsp;to&nbsp;SHM*/</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='448'>448</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;int&nbsp;AGENT_ExtendShm(int&nbsp;size)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='449'>449</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='450'>450</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;int&nbsp;ret&nbsp;=&nbsp;-1;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='451'>451</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if(oidShmFd&nbsp;&gt;=&nbsp;0)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='452'>452</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='453'>453</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;newSize&nbsp;=&nbsp;size&nbsp;+&nbsp;pOidShm-&gt;oidShmSize;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='454'>454</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;ftruncate(oidShmFd,newSize);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='455'>455</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;//Compile&nbsp;Errors</td>
</tr>
<tr class="noCover">
<td class="line"><a name='456'>456</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;//pOidShm&nbsp;=&nbsp;mremap(pOidShm,&nbsp;pOidShm-&gt;oidShmSize,newSize,&nbsp;MREMAP_MAYMOVE);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='457'>457</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;munmap(pOidShm,pOidShm-&gt;oidShmSize);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='458'>458</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;pOidShm&nbsp;=&nbsp;mmap(0,newSize,PROT_READ|PROT_WRITE,MAP_SHARED,oidShmFd,0);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='459'>459</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;pOidShm-&gt;oidShmSize&nbsp;=&nbsp;newSize;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='460'>460</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;ret&nbsp;=&nbsp;0;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='461'>461</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='462'>462</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='463'>463</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;ret;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='464'>464</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='465'>465</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='466'>466</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;tOidObject&nbsp;*&nbsp;AGENT_GetNextOidObject(tOidObject&nbsp;*&nbsp;pAct)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='467'>467</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='468'>468</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if(pAct&nbsp;==&nbsp;NULL&nbsp;)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='469'>469</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='470'>470</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if(pOidShm-&gt;oidCount&nbsp;&gt;&nbsp;0)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='471'>471</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='472'>472</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;&amp;pOidShm-&gt;oidStart[0];</td>
</tr>
<tr class="noCover">
<td class="line"><a name='473'>473</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='474'>474</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;else</td>
</tr>
<tr class="noCover">
<td class="line"><a name='475'>475</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='476'>476</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;NULL;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='477'>477</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='478'>478</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='479'>479</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;//if&nbsp;this&nbsp;is&nbsp;the&nbsp;last&nbsp;index</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='480'>480</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if(pOidShm-&gt;oidCount&nbsp;&lt;=&nbsp;(pAct-&gt;index+1))</td>
</tr>
<tr class="noCover">
<td class="line"><a name='481'>481</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='482'>482</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;NULL;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='483'>483</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='484'>484</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='485'>485</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;//CALC_OBJ_SIZE(step,pAct-&gt;len,pAct-&gt;len&nbsp;&lt;=&nbsp;OID_BUFFER_LEN);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='486'>486</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;pAct&nbsp;=&nbsp;(tOidObject*)&nbsp;(&nbsp;((unsigned&nbsp;int)&nbsp;pAct)&nbsp;+&nbsp;((unsigned&nbsp;int)&nbsp;&nbsp;pAct-&gt;objLen));</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='487'>487</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;pAct;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='488'>488</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='489'>489</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='490'>490</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;tOidObject&nbsp;*&nbsp;AGENT_GetOidObject(oid&nbsp;*&nbsp;anOID,size_t&nbsp;anOID_len)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='491'>491</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='492'>492</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;tOidObject&nbsp;*&nbsp;ret&nbsp;=&nbsp;NULL;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='493'>493</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;AGENT_CreateShm();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='494'>494</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if(oidShmFd&nbsp;&gt;=&nbsp;0)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='495'>495</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='496'>496</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;tOidObject&nbsp;*&nbsp;pAct&nbsp;=&nbsp;AGENT_GetNextOidObject(NULL);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='497'>497</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;while(pAct&nbsp;!=&nbsp;NULL)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='498'>498</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='499'>499</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if(0==snmp_oid_compare&nbsp;&nbsp;(anOID,anOID_len,pAct-&gt;anOID,pAct-&gt;anOID_length))</td>
</tr>
<tr class="noCover">
<td class="line"><a name='500'>500</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='501'>501</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ret=pAct;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='502'>502</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='503'>503</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='504'>504</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;pAct&nbsp;=&nbsp;AGENT_GetNextOidObject(pAct);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='505'>505</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='506'>506</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='507'>507</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;ret;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='508'>508</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='509'>509</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='510'>510</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;tOidObject&nbsp;*&nbsp;AGENT_GetFreeOidObject(int&nbsp;size)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='511'>511</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='512'>512</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;tOidObject&nbsp;*&nbsp;pAct;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='513'>513</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;tOidObject&nbsp;*&nbsp;pLast&nbsp;=&nbsp;NULL;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='514'>514</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;/*pAct&nbsp;=&nbsp;AGENT_GetNextOidObject(NULL);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='515'>515</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;while(pAct&nbsp;!=&nbsp;NULL)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='516'>516</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='517'>517</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;pLast&nbsp;=&nbsp;pAct;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='518'>518</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;pAct&nbsp;=&nbsp;AGENT_GetNextOidObject(pAct);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='519'>519</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}*/</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='520'>520</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;AGENT_ExtendShm(size);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='521'>521</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;pAct&nbsp;=&nbsp;AGENT_GetNextOidObject(NULL);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='522'>522</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;while(pAct&nbsp;!=&nbsp;NULL)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='523'>523</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='524'>524</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;pLast&nbsp;=&nbsp;pAct;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='525'>525</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;pAct&nbsp;=&nbsp;AGENT_GetNextOidObject(pAct);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='526'>526</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='527'>527</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;pOidShm-&gt;oidCount++;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='528'>528</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;pAct&nbsp;=&nbsp;AGENT_GetNextOidObject(pLast);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='529'>529</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if(pAct&nbsp;!=&nbsp;NULL)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='530'>530</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='531'>531</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;pAct-&gt;objLen&nbsp;=&nbsp;size;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='532'>532</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;pAct-&gt;index&nbsp;=&nbsp;pOidShm-&gt;oidCount-1;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='533'>533</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='534'>534</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;pAct;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='535'>535</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='536'>536</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='537'>537</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;void&nbsp;AGENT_SetOidObjectValue(tOidObject&nbsp;*&nbsp;object,netsnmp_variable_list&nbsp;*&nbsp;stData)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='538'>538</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='539'>539</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;size_t&nbsp;bufferLen&nbsp;=&nbsp;object-&gt;objLen&nbsp;-&nbsp;sizeof(tOidObject)+OID_BUFFER_LEN;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='540'>540</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;object-&gt;type&nbsp;=&nbsp;stData-&gt;type;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='541'>541</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if(bufferLen&nbsp;&gt;=&nbsp;stData-&gt;val_len)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='542'>542</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='543'>543</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;memcpy(object-&gt;buf,&nbsp;stData-&gt;val.string,stData-&gt;val_len);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='544'>544</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;object-&gt;len&nbsp;=&nbsp;stData-&gt;val_len;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='545'>545</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;object-&gt;buf[stData-&gt;val_len]=0;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='546'>546</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='547'>547</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;else</td>
</tr>
<tr class="noCover">
<td class="line"><a name='548'>548</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='549'>549</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;memcpy(object-&gt;buf,&nbsp;stData-&gt;val.string,bufferLen);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='550'>550</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;object-&gt;len&nbsp;=&nbsp;bufferLen;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='551'>551</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;object-&gt;buf[bufferLen]=0;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='552'>552</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='553'>553</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='554'>554</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='555'>555</a></td>
<td class="hits">0</td>
<td class="code">INTERNAL_SYM&nbsp;tWagoSnmpReturnCode&nbsp;AGENT_CreateNewOidObject(oid&nbsp;*&nbsp;anOID,&nbsp;size_t&nbsp;anOID_len,netsnmp_variable_list&nbsp;*&nbsp;stData,uint8_t&nbsp;readOnly)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='556'>556</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='557'>557</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;tWagoSnmpReturnCode&nbsp;result&nbsp;=&nbsp;WAGOSNMP_RETURN_ERROR_SHM;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='558'>558</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;AGENT_CreateShm();</td>
</tr>
<tr class="noCover">
<td class="line"><a name='559'>559</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='560'>560</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;if(oidShmFd&nbsp;&gt;=&nbsp;0)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='561'>561</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='562'>562</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;tOidObject&nbsp;*&nbsp;pObj;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='563'>563</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;objectSize;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='564'>564</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='565'>565</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;CALC_OBJ_SIZE(objectSize,stData-&gt;val_len,stData-&gt;val.string&nbsp;==&nbsp;stData-&gt;buf);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='566'>566</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;AGENT_MutexLock();</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='567'>567</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;pObj&nbsp;=&nbsp;AGENT_GetFreeOidObject(objectSize);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='568'>568</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='569'>569</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;if(pObj&nbsp;!=&nbsp;NULL)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='570'>570</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='571'>571</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;pObj-&gt;readOnly&nbsp;=&nbsp;readOnly;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='572'>572</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;memcpy(pObj-&gt;anOID,anOID,anOID_len*sizeof(oid));</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='573'>573</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;pObj-&gt;anOID_length&nbsp;=&nbsp;anOID_len;</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='574'>574</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;AGENT_SetOidObjectValue(pObj,stData);</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='575'>575</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;result&nbsp;=&nbsp;WAGOSNMP_RETURN_OK;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='576'>576</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='577'>577</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;AGENT_MutexUnlock();</td>
</tr>
<tr class="noCover">
<td class="line"><a name='578'>578</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='579'>579</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='580'>580</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;return&nbsp;result;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='581'>581</a></td>
<td class="hits"></td>
<td class="code">}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='582'>582</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='583'>583</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='584'>584</a></td>
<td class="hits"></td>
<td class="code">//----&nbsp;End&nbsp;of&nbsp;source&nbsp;file&nbsp;------------------------------------------------------</td>
</tr>

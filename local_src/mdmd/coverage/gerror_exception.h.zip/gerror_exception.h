<tr class="noCover">
<td class="line"><a name='1'>1</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;This&nbsp;Source&nbsp;Code&nbsp;Form&nbsp;is&nbsp;subject&nbsp;to&nbsp;the&nbsp;terms&nbsp;of&nbsp;the&nbsp;Mozilla&nbsp;Public</td>
</tr>
<tr class="noCover">
<td class="line"><a name='2'>2</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;License,&nbsp;v.&nbsp;2.0.&nbsp;If&nbsp;a&nbsp;copy&nbsp;of&nbsp;the&nbsp;MPL&nbsp;was&nbsp;not&nbsp;distributed&nbsp;with&nbsp;this</td>
</tr>
<tr class="noCover">
<td class="line"><a name='3'>3</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;file,&nbsp;You&nbsp;can&nbsp;obtain&nbsp;one&nbsp;at&nbsp;http://mozilla.org/MPL/2.0/.</td>
</tr>
<tr class="noCover">
<td class="line"><a name='4'>4</a></td>
<td class="hits"></td>
<td class="code">//</td>
</tr>
<tr class="noCover">
<td class="line"><a name='5'>5</a></td>
<td class="hits"></td>
<td class="code">//&nbsp;Copyright&nbsp;(c)&nbsp;2018-2022&nbsp;WAGO&nbsp;GmbH&nbsp;&amp;&nbsp;Co.&nbsp;KG</td>
</tr>
<tr class="noCover">
<td class="line"><a name='6'>6</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='7'>7</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='8'>8</a></td>
<td class="hits"></td>
<td class="code">#ifndef&nbsp;GERROR_EXCEPTION_H</td>
</tr>
<tr class="noCover">
<td class="line"><a name='9'>9</a></td>
<td class="hits"></td>
<td class="code">#define&nbsp;GERROR_EXCEPTION_H</td>
</tr>
<tr class="noCover">
<td class="line"><a name='10'>10</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='11'>11</a></td>
<td class="hits"></td>
<td class="code">#include&nbsp;&lt;string&gt;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='12'>12</a></td>
<td class="hits"></td>
<td class="code">#include&nbsp;&lt;exception&gt;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='13'>13</a></td>
<td class="hits"></td>
<td class="code">#include&nbsp;"glib.h"</td>
</tr>
<tr class="noCover">
<td class="line"><a name='14'>14</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='15'>15</a></td>
<td class="hits"></td>
<td class="code">class&nbsp;GErrorException&nbsp;:&nbsp;public&nbsp;std::exception</td>
</tr>
<tr class="noCover">
<td class="line"><a name='16'>16</a></td>
<td class="hits"></td>
<td class="code">{</td>
</tr>
<tr class="noCover">
<td class="line"><a name='17'>17</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;private:</td>
</tr>
<tr class="noCover">
<td class="line"><a name='18'>18</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;_message;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='19'>19</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;_code;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='20'>20</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;std::string&nbsp;_domain;</td>
</tr>
<tr class="noCover">
<td class="line"><a name='21'>21</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='22'>22</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;public:</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='23'>23</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;explicit&nbsp;GErrorException(&nbsp;GError&nbsp;*err&nbsp;)</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='24'>24</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;_message(&nbsp;err-&gt;message&nbsp;)</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='25'>25</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;,&nbsp;_code(&nbsp;err-&gt;code&nbsp;)</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='26'>26</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;,&nbsp;_domain(&nbsp;g_quark_to_string(&nbsp;err-&gt;domain&nbsp;)&nbsp;)</td>
</tr>
<tr class="noCover">
<td class="line"><a name='27'>27</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{</td>
</tr>
<tr class="coverNone">
<td class="line"><a name='28'>28</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;g_error_free(err);</td>
</tr>
<tr class="noCover">
<td class="line"><a name='29'>29</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='30'>30</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="coverNone">
<td class="line"><a name='31'>31</a></td>
<td class="hits">0</td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;const&nbsp;char*&nbsp;what()&nbsp;const&nbsp;noexcept&nbsp;override&nbsp;{&nbsp;return&nbsp;_message.c_str();&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='32'>32</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;const&nbsp;std::string&nbsp;&amp;&nbsp;domain()&nbsp;{&nbsp;return&nbsp;_domain;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='33'>33</a></td>
<td class="hits"></td>
<td class="code">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;int&nbsp;code()&nbsp;{&nbsp;return&nbsp;_code;&nbsp;}</td>
</tr>
<tr class="noCover">
<td class="line"><a name='34'>34</a></td>
<td class="hits"></td>
<td class="code">};</td>
</tr>
<tr class="noCover">
<td class="line"><a name='35'>35</a></td>
<td class="hits"></td>
<td class="code"></td>
</tr>
<tr class="noCover">
<td class="line"><a name='36'>36</a></td>
<td class="hits"></td>
<td class="code">#endif</td>
</tr>

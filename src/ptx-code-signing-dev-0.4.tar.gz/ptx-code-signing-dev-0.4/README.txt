This repository contains some ready-to-use X.509 for several use cases.
Obviously, they should only be used for development and testing, not to provide
actual security.

To build from git:

```
./autogen.sh && ./configure && make
```

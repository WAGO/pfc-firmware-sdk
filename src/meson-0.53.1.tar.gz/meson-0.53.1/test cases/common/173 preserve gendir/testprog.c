#include"base.h"
#include"com/mesonbuild/subbie.h"

int main(void) {
    return base() + subbie();
}

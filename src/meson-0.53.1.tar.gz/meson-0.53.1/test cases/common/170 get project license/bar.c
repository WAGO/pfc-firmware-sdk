#include<stdio.h>

int main(void) {
    printf("I'm a main project bar.\n");
    return 0;
}

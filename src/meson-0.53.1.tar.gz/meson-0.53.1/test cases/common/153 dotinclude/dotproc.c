#include"stdio.h"

#ifndef WRAPPER_INCLUDED
#error The wrapper stdio.h was not included.
#endif

int main(void) {
    printf("Eventually I got printed.\n");
    return 0;
}

#include<stdio.h>
#include<string.h>

int main(void) {
    if(strcmp(FOO, "bar")) {
        printf("FOO is misquoted: %s\n", FOO);
        return 1;
    }
    return 0;
}

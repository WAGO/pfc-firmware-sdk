#include<stdio.h>

int main(void) {
    printf("Do not have a file layout like this in your own projects.\n");
    printf("This is only to test that this works.\n");
    return 0;
}

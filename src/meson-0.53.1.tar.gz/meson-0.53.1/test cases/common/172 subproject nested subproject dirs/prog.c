int func(void);

int main(void) {
    return func() == 42 ? 0 : 1;
}

#pragma once

int foobar(void);

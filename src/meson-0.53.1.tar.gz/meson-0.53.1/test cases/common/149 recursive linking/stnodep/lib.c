#include "../lib.h"

SYMBOL_EXPORT
int get_stnodep_value (void) {
  return 2;
}

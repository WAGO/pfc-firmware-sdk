#include"funheader.h"

int main(void) {
    return my_wonderful_function() != 42;
}

/*
 * Written by Solar Designer <solar at openwall.com> and placed in the
 * public domain.
 */

#ifndef WORDSET_4K_H__
#define WORDSET_4K_H__

#define WORDSET_4K_LENGTH_MAX		6

extern const char _passwdqc_wordset_4k[][WORDSET_4K_LENGTH_MAX];

#endif /* WORDSET_4K_H__ */

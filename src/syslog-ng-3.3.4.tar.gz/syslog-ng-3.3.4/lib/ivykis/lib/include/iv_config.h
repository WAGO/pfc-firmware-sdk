/* This is an automatically generated file. Please modify 'configure.ac'.
 * It contains missing per-system specific definitions, needed for ivykis and
 * software using it.
 */

#ifndef IV_CONFIG_H
#define IV_CONFIG_H

#include <sys/time.h>
#endif /* IV_CONFIG_H */

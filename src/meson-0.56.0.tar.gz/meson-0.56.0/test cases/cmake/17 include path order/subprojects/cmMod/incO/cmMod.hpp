// cmMod.hpp (O)
#pragma once

#error "cmMod.hpp in incO must not be included"

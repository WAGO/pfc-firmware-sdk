// cmMod.hpp (E)
#pragma once

#error "cmMod.hpp in incE must not be included"

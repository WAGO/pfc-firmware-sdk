#include <string.h>
#include <stdio.h>

#define COMPARER_INCLUDED

#include <config4a.h>
#include <config4b.h>

int main(void) {
    return RESULTA + RESULTB;
}

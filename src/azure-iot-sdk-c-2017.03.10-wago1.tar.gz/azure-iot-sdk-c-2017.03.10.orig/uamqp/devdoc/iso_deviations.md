SRS_CONNECTION_01_239: The ISO does not define what should happen if an OPEN frame is received in the OPENED state.

#link requirements
 
##Overview

link is module that implements the link layer in the AMQP ISO.

##Exposed API

###link_create


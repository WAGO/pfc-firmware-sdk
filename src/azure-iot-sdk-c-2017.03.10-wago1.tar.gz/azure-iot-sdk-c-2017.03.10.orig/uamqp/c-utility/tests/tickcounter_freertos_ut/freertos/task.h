// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef FREERTOS_TASK_H
#define FREERTOS_TASK_H

// This file must exist to keep tickcounter_freertos.c compatible with FreeRTOS


#endif // FREERTOS_TASK_H

// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#define COMPILING_REAL_REAL_STRING_TOKENIZER_H_C

#define GBALLOC_H

#include "real_string_tokenizer.h"
#include "string_tokenizer.c"

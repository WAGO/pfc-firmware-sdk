# To build the iothub_registrymanager_sample sample

Follow the instructions [here](../../../../../doc/get_started/mbed-freescale-k64f-c.md).
#ifndef __LIBPAC_MDIO_H__
#define __LIBPAC_MDIO_H__

#define PAC_MDIO_VERSION             "1.0"
#define PAC_MDIO_MAX_STRING           64
#define PAC_MDIO_DEFAULT_INTERFACE   "eth0"

int mdio_read(char *interface, int phy_id, int location, int *result);
int mdio_write(char *interface, int phy_id, int location, int value);

#endif



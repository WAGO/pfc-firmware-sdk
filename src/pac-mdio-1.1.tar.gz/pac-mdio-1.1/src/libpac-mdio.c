/* 

   pac-mdio: provide read/write access to phy registers over MDIO

   Wago Automation 2012, H. Toews

   Adjusted for integration into get_eth_config.

*/
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>
#include <syslog.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#ifndef __GLIBC__
#include <linux/if_arp.h>
#include <linux/if_ether.h>
#endif

#include <linux/sockios.h>
#include <linux/mii.h>

#include "libpac-mdio.h"

// has to correspond to values defined in config_tool_lib.h
enum eStatusCodePacMdio
{
  ERROR                           = -1,
  SUCCESS                         = 0,
  MISSING_PARAMETER,
  INVALID_PARAMETER,
  FILE_OPEN_ERROR,
  FILE_READ_ERROR,
  FILE_CLOSE_ERROR,
  NOT_FOUND,
  SYSTEM_CALL_ERROR,
  CONFIG_FILE_INCONSISTENT,
  TIMEOUT
};

int libpac_mdio_verbose;

static inline void _set_reg_num(struct mii_ioctl_data *mii, int phy_id, int reg_num);

static int mdio_init(char *interface, struct ifreq *ifr, int *skfd);

static inline void _set_reg_num(struct mii_ioctl_data *mii, int phy_id, int reg_num)
{
  mii->reg_num = reg_num;

  if(phy_id < 0) // phy_id == -1: special case for ksz8863
  {
#define MII_ADDR_KSZ (1<<15)	/* keep in sync with kernel (include/linux/phy.h) */
    mii->reg_num |= MII_ADDR_KSZ;
  }
  else
  {
    mii->phy_id = phy_id;
  }
}

static int mdio_init(char *interface, struct ifreq *ifr, int *skfd)
{

  /* Open a basic socket. */
  if ((*skfd = socket(AF_INET, SOCK_DGRAM,0)) < 0) {
    perror("socket");
    return FILE_OPEN_ERROR;
  }

  memset(ifr, 0, sizeof(*ifr));

  strncpy(ifr->ifr_name, interface ? interface : PAC_MDIO_DEFAULT_INTERFACE, IFNAMSIZ);

  return SUCCESS;
}

int mdio_read(char *interface, int phy_id, int location, int *result)
{
  int ret = SUCCESS;
  struct ifreq ifr;
  struct mii_ioctl_data *mii;
 
  int skfd;

  ret = mdio_init(interface, &ifr, &skfd);

  if(SUCCESS == ret)
  {

    mii = (struct mii_ioctl_data *)&ifr.ifr_ifru;
    _set_reg_num(mii, phy_id, location);
  
    if (libpac_mdio_verbose)
      printf("%s: mii->phy_id=0x%x, mii->reg_num=0x%x, mii->val_out=0x%x.\n",
          __func__, mii->phy_id, mii->reg_num, mii->val_out);

    if (ioctl(skfd, SIOCGMIIREG, &ifr) < 0) {
      fprintf(stderr, "SIOCGMIIREG on %s failed: %s\n", ifr.ifr_name, 
          strerror(errno));

      close(skfd);

      ret = SYSTEM_CALL_ERROR;
    }
    else 
    {
      if (libpac_mdio_verbose)
        printf("%s: mii->phy_id=0x%x, mii->reg_num=0x%x, mii->val_out=0x%x.\n",
            __func__, mii->phy_id, mii->reg_num, mii->val_out);

      *result = mii->val_out;

      close(skfd);
    }
  }

  return ret;
}

int mdio_write(char *interface, int phy_id, int location, int value)
{
  int ret = SUCCESS;
  struct ifreq ifr;
  struct mii_ioctl_data *mii;
 
  int skfd;

  ret = mdio_init(interface, &ifr, &skfd);

  if(SUCCESS == ret)
  {
    mii = (struct mii_ioctl_data *)&ifr.ifr_ifru;
    _set_reg_num(mii, phy_id, location); 

    mii->val_in = value;

    if (ioctl(skfd, SIOCSMIIREG, &ifr) < 0) {
      fprintf(stderr, "SIOCSMIIREG on %s failed: %s\n", ifr.ifr_name,
          strerror(errno));
      ret = SYSTEM_CALL_ERROR;
    }

    close(skfd);
  }

	return ret;
}




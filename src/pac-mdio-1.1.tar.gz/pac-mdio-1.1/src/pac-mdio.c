/* 

   pac-mdio: provide read/write access to phy registers over MDIO

   Wago Automation 2012, H. Toews

*/

#include <stdio.h>
#include <getopt.h>
#include <string.h>
#include <stdlib.h>

#include "libpac-mdio.h"

// has to correspond to values defined in config_tool_lib.h
#define SUCCESS 0

extern int libpac_mdio_verbose;

const char *usage =
"PAC200 mii tool, Version: %s, Wago Automation 2012\n"
"usage: %s [ -i <interface> ] [ -p <phy> ] -r <phyreg> [ -v <value> ] [ -h ] [ -D ]\n"
"       -i,               interface (default: 'eth0')\n"
"       -p,               phy address (decimal)\n"
"       -r,               phy register (decimal)\n"
"       -v,               phy register value (hex)\n"
"       -D,               verbose mode with debug messages\n"
"       -h,               this help text\n";

int main(int argc, char **argv)
{
	int ret = 0;
	int c;
	int is_write = 0;
	int phy_no = -1; 
	int phy_reg = 0;
	int phy_reg_val = 0;
	int help = 0;
  char *interface = NULL;
	
	/* parse options */
	while ((c = getopt(argc, argv, "i:p:r:v:Dh")) != EOF)
		switch (c) {
		case 'i': interface = optarg; break;
		case 'p': phy_no = atoi(optarg); break;
		case 'r': phy_reg = atoi(optarg); break;
		case 'v': phy_reg_val = (int) strtol(optarg, NULL, 16); is_write++; break; /* atoi(optarg) */
		case 'D': libpac_mdio_verbose = 1; break;
		case 'h': help++;
		}
	
	if (help) {
		fprintf(stderr, usage, PAC_MDIO_VERSION, argv[0]);
		return 0;
	}

	if (libpac_mdio_verbose)
		printf("%s: phy_no=0x%x, phy_reg=0x%x, phy_reg_val=0x%x.\n",
		       __func__, phy_no, phy_reg, phy_reg_val);

	/* Now do the read or write */
	if (is_write)
		ret = mdio_write(interface, phy_no, phy_reg, phy_reg_val);
	else {
		int output;
		ret = mdio_read(interface, phy_no, phy_reg, &output);

    if(SUCCESS == ret)
    {
      printf("%x\n", output);
    }
	}

	return ret;
}
